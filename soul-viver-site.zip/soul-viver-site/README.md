# Soul Viver — Site institucional

Site estático (HTML, CSS e JavaScript puros — sem build, sem dependências) para a marca Soul Viver.

## Estrutura

```
index.html   → estrutura e conteúdo da página
style.css    → todo o estilo visual (cores, tipografia, layout responsivo)
script.js    → animação de revelação suave das seções ao rolar a página
```

## Como publicar no GitHub Pages

1. Crie um repositório novo no GitHub e suba estes 3 arquivos (mantendo os nomes).
2. Vá em **Settings → Pages**.
3. Em "Source", selecione a branch `main` e a pasta `/ (root)`.
4. Salve. Em alguns minutos o site estará no ar em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.

## Contato usado no site

- WhatsApp: https://wa.me/5562985451979
- Instagram: https://www.instagram.com/soulviver/

Nenhum valor de serviço é exibido no site — todos os botões de ação redirecionam para o WhatsApp.
